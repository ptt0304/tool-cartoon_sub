from dataclasses import dataclass, field, asdict
from cartoon_sub.translation.context_models import StoryContext

@dataclass(init=False)
class Segment:
    id: int
    start: float
    end: float
    zh: str = ""
    vi_subtitle: str = ""
    vi_dubbing: str = ""
    speaker_id: str = "SPK_UNKNOWN"
    speaker_name: str = "Unknown"
    speaker_confidence: float | None = None
    transcript_confidence: float | None = None
    overlap: bool = False
    overlap_group: str | None = None
    translation_mode: str = "balanced_dubbing"
    target_override: int | None = None
    zh_syllables: int = 0
    vi_syllables: int = 0
    vi_subtitle_syllables: int = 0
    target_syllables: int = 0
    syllable_delta: int = 0
    semantic_compression: bool = False
    meaning_preservation: str = "unknown"
    dubbing_optimized: bool = False
    dubbing_status: str = "not_started"
    dubbing_fingerprint: str = ""
    syllable_warnings: list[str] = field(default_factory=list)
    tts_audio_path: str | None = None
    tts_duration: float | None = None
    tts_speed_factor: float | None = None
    tts_alignment_status: str = "not_imported"

    def __init__(self, id, start, end, zh="", vi=None, vi_subtitle=None, vi_dubbing=None, **kwargs):
        from dataclasses import fields, MISSING
        self.id, self.start, self.end, self.zh = id, start, end, zh
        self.vi_subtitle = vi if vi is not None else (vi_subtitle if vi_subtitle is not None else "")
        self.vi_dubbing = self.vi_subtitle if vi_dubbing is None or (vi is not None and not kwargs.get("dubbing_optimized",False)) else vi_dubbing
        for f in fields(self):
            if f.name in ("id","start","end","zh","vi_subtitle","vi_dubbing"): continue
            if f.name in kwargs: value=kwargs.pop(f.name)
            elif f.default_factory is not MISSING: value=f.default_factory()
            else: value=f.default
            setattr(self,f.name,value)
        if kwargs: raise TypeError(f"Unknown utterance fields: {', '.join(kwargs)}")
        self.validate()
        self.recalculate()

    def validate(self):
        import math
        from cartoon_sub.speaker.models import Speaker
        from cartoon_sub.translation.modes import TranslationMode
        if type(self.id) is not int or self.id < 1: raise ValueError("ID must be a positive integer")
        if any(type(t) not in (float,int) or not math.isfinite(t) for t in (self.start,self.end)):
            raise ValueError("Invalid timestamp")
        if self.start < 0 or self.end <= self.start: raise ValueError("Requires 0 <= start < end")
        if any(not isinstance(t,str) for t in (self.zh,self.vi_subtitle,self.vi_dubbing)):
            raise ValueError("Text must be a string")
        Speaker(self.speaker_id,self.speaker_name)
        TranslationMode(self.translation_mode)
        for confidence in (self.speaker_confidence,self.transcript_confidence):
            if confidence is not None and (type(confidence) not in (int,float) or not math.isfinite(confidence) or not 0<=confidence<=1):
                raise ValueError("Confidence must be null or in [0,1]")
        if self.target_override is not None and (type(self.target_override) is not int or self.target_override<1):
            raise ValueError("Target override must be a positive integer")
        if self.tts_duration is not None and (type(self.tts_duration) not in (int,float) or not math.isfinite(self.tts_duration) or self.tts_duration<=0):
            raise ValueError("TTS duration must be positive")
        if self.tts_audio_path is not None and not isinstance(self.tts_audio_path,str): raise ValueError("TTS path must be a string")

    @property
    def vi(self):
        return self.vi_subtitle

    @vi.setter
    def vi(self,value):
        self.vi_subtitle=value
        if not self.dubbing_optimized: self.vi_dubbing=value
        else: self.dubbing_status="stale"
        self.recalculate()

    @property
    def duration(self): return self.end-self.start

    def recalculate(self, settings=None):
        from cartoon_sub.syllable.chinese import count as zh_count
        from cartoon_sub.syllable.vietnamese import count as vi_count
        from cartoon_sub.syllable.target import DubbingSettings, target_syllables
        config=settings or DubbingSettings()
        if self.translation_mode=="time_fit":
            from dataclasses import replace
            config=replace(config,target_strategy="time_based")
        zh,vi,sub=zh_count(self.zh),vi_count(self.vi_dubbing),vi_count(self.vi_subtitle)
        self.zh_syllables,self.vi_syllables,self.vi_subtitle_syllables=zh.count,vi.count,sub.count
        self.target_syllables=self.target_override or target_syllables(zh.count,self.duration,config)
        self.syllable_delta=vi.count-self.target_syllables
        self.syllable_warnings=list(dict.fromkeys(zh.warnings+vi.warnings+sub.warnings))
        if self.tts_duration is not None:
            self.tts_speed_factor=self.tts_duration/self.duration
            self.tts_alignment_status="warning" if self.tts_duration>self.duration else "fits"

    def to_dict(self):
        return {**asdict(self), "duration":self.duration}

    @classmethod
    def from_dict(cls,data):
        data=dict(data)
        data.pop("duration",None)
        data.pop("slot_duration",None)
        return cls(**data)

SubtitleSegment = Segment

@dataclass
class Mask:
    enabled: bool = False
    kind: str = "solid"
    x: int = 0
    y: int = 0
    width: int = 0
    height: int = 0

@dataclass
class SubtitleStyle:
    font: str = "Arial"
    font_size: int = 42
    bold: bool = False
    outline: float = 2
    shadow: float = 1
    alignment: int = 2
    margin_bottom: int = 30
    max_lines: int = 2

@dataclass
class Project:
    name: str
    source_video_path: str
    schema_version: int = 2
    metadata: dict = field(default_factory=dict)
    segments: list[Segment] = field(default_factory=list)
    transcription_status: str = "not_started"
    translation_prompt: str = ""
    translation_preset: str = "Natural Vietnamese"
    glossary: dict[str, str] = field(default_factory=dict)
    mask: Mask = field(default_factory=Mask)
    subtitle_style: SubtitleStyle = field(default_factory=SubtitleStyle)
    selected_models: dict = field(default_factory=lambda: {"transcription": "mock", "translation": "mock"})
    cache_hashes: dict = field(default_factory=dict)
    chunk_states: dict = field(default_factory=dict)
    translation_genres: list[str] = field(default_factory=list)
    story_context: dict = field(default_factory=lambda: StoryContext().to_dict())
    context_proposal: dict = field(default_factory=dict)
    context_source_hash: str = ""
    context_proposal_hash: str = ""
    context_status: str = "not_started"
    translation_status: str = "not_started"
    translation_notes: dict = field(default_factory=dict)

    speakers: dict = field(default_factory=dict)
    speaker_review_hash: str = ""
    dubbing_settings: dict = field(default_factory=dict)

    def to_dict(self):
        from cartoon_sub.speaker.service import refresh_timeline
        refresh_timeline(self)
        data=asdict(self)
        data["schema_version"]=2
        data["master_timeline"]=[s.to_dict() for s in self.segments]
        data.pop("segments",None)
        return data

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        if data.get("schema_version") not in (1,2):
            raise ValueError("Unsupported project schema")
        data["schema_version"]=2
        rows=data.pop("master_timeline", data.pop("segments",[]))
        data["segments"] = [Segment.from_dict(s) for s in rows]
        ids = [s.id for s in data["segments"]]
        if len(ids) != len(set(ids)):
            raise ValueError("Duplicate subtitle IDs")
        data["mask"] = Mask(**data.get("mask", {}))
        data["subtitle_style"] = SubtitleStyle(**data.get("subtitle_style", {}))
        data["story_context"] = StoryContext.from_dict(data.get("story_context", {})).to_dict()
        if data.get("context_proposal"):
            data["context_proposal"] = StoryContext.from_dict(data["context_proposal"]).to_dict()
        from cartoon_sub.translation.presets import GENRES
        if not isinstance(data.get("translation_genres", []), list) or any(g not in GENRES for g in data.get("translation_genres", [])):
            raise ValueError("Thể loại dịch không hợp lệ")
        project=cls(**data)
        from cartoon_sub.speaker.service import refresh_timeline
        refresh_timeline(project)
        return project
